def kubus(x) :
    return x * x * x

def balok(p, l, t) :
    return p * l * t

def limas4(p, l, t) :
    return (1 / 3) * (p * l) * t

def prisma3(a, t, tp) :
    return ((a * t) / 2) * tp